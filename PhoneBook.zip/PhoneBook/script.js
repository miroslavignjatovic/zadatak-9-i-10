// Array to store contacts
let contacts = [];

// Function to add a new contact
function addContact() {
  // Get input values
  const firstName = document.getElementById('firstName').value.trim();
  const lastName = document.getElementById('lastName').value.trim();
  const phoneNumber = document.getElementById('phoneNumber').value.trim();

  // Validate input values
  if (firstName === '' || lastName === '' || phoneNumber === '') {
    alert('Please enter all fields');
    return;
  }

  // Create new contact object
  const newContact = {
    firstName,
    lastName,
    phoneNumber
  };

  // Add new contact to array
  contacts.push(newContact);

  // Clear input fields
  document.getElementById('firstName').value = '';
  document.getElementById('lastName').value = '';
  document.getElementById('phoneNumber').value = '';

  // Add new contact to table
  const table = document.getElementById('contactList');
  const row = table.insertRow();
  const cell1 = row.insertCell();
  const cell2 = row.insertCell();
  const cell3 = row.insertCell();
  const cell4 = row.insertCell();
  cell1.innerHTML = newContact.firstName;
  cell2.innerHTML = newContact.lastName;
  cell3.innerHTML = newContact.phoneNumber;
  cell4.innerHTML = '<button onclick="editContact(this)" class="btn btn-success">Edit</button><button onclick="deleteContact(this)" class="btn btn-danger">Delete</button>';
}

// Function to delete a contact
function deleteContact(button) {
  // Get index of contact to delete
  const row = button.parentNode.parentNode;
  const rowIndex = row.rowIndex - 1; // Subtract 1 to account for the table header

  // Remove contact from array
  contacts.splice(rowIndex, 1);

  // Remove contact from table
  const table = document.getElementById('contactList');
  table.deleteRow(rowIndex);
}

// Function to edit a contact
function editContact(button) {
  // Get index of contact to edit
  const row = button.parentNode.parentNode;
  const rowIndex = row.rowIndex -1; // Subtract 1 to account for the table header

  // Get contact from array
  const contact = contacts[rowIndex];
  document.getElementById('firstName').value = contact.firstName;
  document.getElementById('lastName').value = contact.lastName;
  document.getElementById('phoneNumber').value = contact.phoneNumber;
  row.parentNode.removeChild(row);
  contact.splice(rowIndex, 1);
  
}

