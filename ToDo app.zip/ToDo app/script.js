// Define a ToDo object
class ToDo {
    constructor(name, isCompleted) {
      this.name = name;
      this.isCompleted = isCompleted;
    }
  }
  
  // Initialize an empty array to store todos
  let todos = [];
  
  // Get DOM elements
  const todoInput = document.getElementById("new-todo");
  const addBtn = document.getElementById("add-btn");
  const todoList = document.getElementById("todo-list");
  
  // Function to add a new todo
  function addTodo() {
    const todoName = todoInput.value.trim();
    if (todoName !== "") {
      // Create a new ToDo object and add it to the todos array
      const todo = new ToDo(todoName, false);
      todos.push(todo);
  
      // Update the UI
      const todoItem = document.createElement("li");
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.addEventListener("change", () => {
        // Update the isCompleted property of the corresponding ToDo object
        todo.isCompleted = checkbox.checked;
        if (todo.isCompleted) {
          todoItem.style.textDecoration = "line-through";
        } else {
          todoItem.style.textDecoration = "none";
        }
      });
      const todoText = document.createTextNode(todoName);
      todoItem.appendChild(checkbox);
      todoItem.appendChild(todoText);
      todoList.appendChild(todoItem);
  
      // Clear the input field
      todoInput.value = "";
    }
  }
  
  // Add event listener to the Add button
  addBtn.addEventListener("click", addTodo);
  
  
  