﻿using System.ComponentModel.Design;

namespace cas3zadatak6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            int[] numberArray = new int[20];
            Random rnd = new Random();

            for (int i = 0; i < numberArray.Length; i++)
            {
                numberArray[i] = rnd.Next(1, 100);
                Console.WriteLine(numberArray[i]);

            }
            Console.WriteLine("Unesite neki broj: ");
            int input = int.Parse(Console.ReadLine());

            bool found = false;
            for (int i = 0; i < numberArray.Length; i++)
            {
                if (input == numberArray[i])
                {
                    found = true;
                    break;
                }
            }

            if (found)
            {
                Console.WriteLine("Uneti broj vec postoji.");
            }
            else
            {
                Console.WriteLine("Uneti broj ne postoji.");
            }
        }
    }
}