﻿namespace Cas3zadatak1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("..............................");

            int[] numbersArrayA = { 67, 32, 39, 74, 57, 17, 80, 96 };

            //FOR PETLJA
            //for (int i = 0; i < numbersArrayA.Length; i++)
            //Console.WriteLine(numbersArrayA[i]);

            Console.WriteLine("..............................");

            //WHILE PETLJA
            int i = 0;
            while (i < numbersArrayA.Length)
            {
                Console.WriteLine(numbersArrayA[i]);
                i++;
            }

            Console.WriteLine("..............................");

            //FOREACH
            foreach ( int numbers in numbersArrayA)
            {
            Console.WriteLine(numbers);
            }
           
        }
    }
}