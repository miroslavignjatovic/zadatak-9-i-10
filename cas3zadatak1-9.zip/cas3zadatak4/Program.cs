﻿namespace cas3zadatak4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            string[] studentsG1 = new string[] { "Milan", "Biljana", "Vitomir", "Attila", "Dalibor" };
            string[] studentsG2 = new string[] { "David", "Miroslav", "Igor", "Marko", "Nikola" };

            Console.WriteLine("Please enter 1 or 2");
            int number = int.Parse(Console.ReadLine());

            if (number == 1) {
                foreach (string students in studentsG1)
                {
                    Console.WriteLine(students);
                }
            }
            else {
                foreach (string students in studentsG2)
                {
                    Console.WriteLine(students);
                }
                    
            }
        }
    }
}