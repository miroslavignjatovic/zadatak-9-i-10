﻿namespace cas3zadatak5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numberArray = new int[20];
            Random random = new Random();   
            for (int i = 0; i < numberArray.Length; i++)
            {
                numberArray[i] = random.Next(1, 100);
                Console.WriteLine(numberArray[i]);
            }
            Console.WriteLine("...........................");
            int duplicateCount = 0;
            for (int i = 0; i < numberArray.Length; i++)
            {
                for (int j = i + 1; j < numberArray.Length; j++)
                {
                    if (numberArray[i] == numberArray[j])
                    {
                        duplicateCount++;
                        break;
                    }
                }
            }
            Console.WriteLine("Number of duplicate numbers: " + duplicateCount);
        }

    }
}
