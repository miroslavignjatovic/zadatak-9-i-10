﻿using System;
using System.ComponentModel.DataAnnotations;

namespace cas3zadatak7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            string[] msgArr = { "Send data", "Message arr", "Calculate data", "SEDC Code Academy C# basic", "Play" };
            
            string longestString = "";
            int maxLength = 0;

            foreach (string message in msgArr)
            {
                if (message.Length > maxLength)
                {
                    maxLength = message.Length;
                    longestString = message;
                }
            }

            Console.WriteLine("Longest string: " + longestString);
            Console.WriteLine("Number of characters: " + maxLength);
        }
    }








        }

