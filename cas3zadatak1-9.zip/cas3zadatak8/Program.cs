﻿using System.Diagnostics;

namespace cas3zadatak8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            int[,] table = new int[5, 4];
            Random random = new Random();

            
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    table[i, j] = random.Next(1, 101);
                }
            }

            
            int row = 0;
            while (row < 5)
            {
                int col = 0;
                while (col < 4)
                {
                    Console.Write(table[row, col] + "\t");
                    col++;
                }
                Console.WriteLine();
                row++;
            }

            Console.WriteLine();
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Console.Write(table[i, j] + "\t");
                }
                Console.WriteLine();
            }

            int count = 0;
            int sum = 0;
            int minValue = int.MaxValue;
            int maxValue = int.MinValue;

            Stopwatch stopwatch = Stopwatch.StartNew(); 

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    int value = table[i, j];
                    count++;
                    sum += value;
                    minValue = Math.Min(minValue, value);
                    maxValue = Math.Max(maxValue, value);
                }
            }

            stopwatch.Stop(); 

           
            double average = (double)sum / count;

            
            Console.WriteLine();
            Console.WriteLine("Count of values: " + count);
            Console.WriteLine("Sum of all values: " + sum);
            Console.WriteLine("Minimum value: " + minValue);
            Console.WriteLine("Maximum value: " + maxValue);
            Console.WriteLine("Average value: " + average);
            Console.WriteLine("Execution time: " + stopwatch.Elapsed);

            Console.ReadLine();
        }
    }
}