﻿namespace cas3zadatak3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            int[] randomArray = new int[100];
            Random random = new Random();

            for (int i = 0; i < randomArray.Length; i++)
            {
                
                int randomIndex = random.Next(1, 100);
                randomArray[randomIndex] = i;
                Console.WriteLine(randomIndex);
            }
            int sum = randomArray.Sum();
            Console.WriteLine("Sum of random numbers is:"+sum);

        }
    }
}