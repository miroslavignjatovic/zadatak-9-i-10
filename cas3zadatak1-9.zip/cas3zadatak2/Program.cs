﻿using System.Diagnostics.Metrics;

namespace cas3zadatak2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            int[] integerArray = new int[6];
            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine("Enter integer no." + (i+1)+":");
                int number = int.Parse(Console.ReadLine());
                integerArray[i] = number;
            }
            int sum = integerArray.Sum();
            Console.WriteLine("The result is:"+sum);
        }
    }
}